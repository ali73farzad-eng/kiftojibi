package com.personal.kiftojibi;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.SharedPreferences;
import android.util.Base64;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class MainActivity extends Activity {
    private WebView web;
    private SharedPreferences prefs;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(33,29,57));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(33,29,57));
        prefs = getSharedPreferences("kiftojibi_account", MODE_PRIVATE);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new AuthBridge(), "AndroidAuth");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    private String hash(String password, String salt) throws Exception {
        byte[] saltBytes = Base64.decode(salt, Base64.NO_WRAP);
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), saltBytes, 120000, 256);
        byte[] out = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        spec.clearPassword();
        return Base64.encodeToString(out, Base64.NO_WRAP);
    }
    private String json(boolean ok, String extra) { return "{\"ok\":"+ok+extra+"}"; }
    public class AuthBridge {
        @JavascriptInterface public boolean hasAccount() { return prefs.contains("user"); }
        @JavascriptInterface public String createAccount(String user, String pass) {
            if(user==null || user.trim().length()<3 || pass==null || pass.length()<6) return json(false,",\"message\":\"نام کاربری حداقل ۳ و رمز حداقل ۶ نویسه باشد.\"");
            if(hasAccount()) return json(false,",\"message\":\"حساب قبلاً ساخته شده است.\"");
            try { byte[] s=new byte[16]; new SecureRandom().nextBytes(s); String salt=Base64.encodeToString(s,Base64.NO_WRAP); String h=hash(pass,salt); prefs.edit().putString("user",user.trim()).putString("salt",salt).putString("hash",h).apply(); return json(true,",\"username\":\""+esc(user.trim())+"\""); }
            catch(Exception e){ return json(false,",\"message\":\"ساخت حساب انجام نشد.\""); }
        }
        @JavascriptInterface public String verifyCredentials(String user, String pass) {
            try { if(!prefs.contains("user") || !prefs.getString("user","").equalsIgnoreCase(user.trim())) return json(false,""); String h=hash(pass,prefs.getString("salt","")); boolean ok=h.equals(prefs.getString("hash","")); return ok?json(true,",\"username\":\""+esc(prefs.getString("user",""))+"\""):json(false,""); }
            catch(Exception e){ return json(false,""); }
        }
        @JavascriptInterface public String changePassword(String current, String next) {
            try { if(next==null || next.length()<6) return json(false,",\"message\":\"رمز جدید باید حداقل ۶ نویسه باشد.\""); if(!verifyCredentials(prefs.getString("user",""),current).contains("\"ok\":true")) return json(false,",\"message\":\"رمز فعلی صحیح نیست.\""); byte[] s=new byte[16]; new SecureRandom().nextBytes(s); String salt=Base64.encodeToString(s,Base64.NO_WRAP); prefs.edit().putString("salt",salt).putString("hash",hash(next,salt)).apply(); return json(true,""); }
            catch(Exception e){ return json(false,",\"message\":\"تغییر رمز انجام نشد.\""); }
        }
        private String esc(String s){ return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n",""); }
    }
    @Override public void onBackPressed() { if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
